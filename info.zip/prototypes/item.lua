ezlib.item = {}
function ezlib.item.add (fname, ficon, fflags, fsubgroup, forder, fstack_size, ficon_size)
  item = {}
  if ficon_size == 0 or ficon_size == nil then
    ficon_size = 32
  end
  if fstack_size == 0 or fstack_size == nil then
    fstack_size = 100
  end
  if forder == 0 or forder == nil then
    forder = "a"
  end
  if fflags == 0 or fflags == nil then
    fflags = {"goes-to-main-inventory"}
  end
  if fsubgroup == 0 or fsubgroup == nil then
    fsubgroup = "other"
  end
  item.type = "item"
  item.name = fname
  item.icon = ficon
  item.flags = fflags
  item.subgroup = fsubgroup
  item.order = forder
  item.stack_size = fstack_size
  item.icon_size = ficon_size
  data:extend({item})
end