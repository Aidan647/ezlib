ezlib = {}


require("other")
require("prototypes.item")
require("recipe")
require("tech")


log(ezlib.tech.find.unlock_recipe("processing-unit"))
ezlib.log_tbl(ezlib.tech.find.unlock_modifer("ammo-damage")))


